"""Shape generators on the normalized square [-1, 1]².

A shape maps `n_points` to `n_points` vertices equally spaced by arc length,
plus the first vertex repeated at the end to close the curve. Nothing here
knows about latitude, longitude or metres.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from route_engine.shapes.circle import circle
from route_engine.shapes.heart import heart
from route_engine.shapes.outline import Outline, read_outline
from route_engine.shapes.resample import Point

ShapeFn = Callable[[int], list[Point]]

# Outlines drawn in JSON (ADR-0035), shipped with the package: the catalogue
# shapes and the ones only tried from the CLI, like the house.
OUTLINES = Path(__file__).with_name("outlines")

# Adding a shape: write its module, or its outline in OUTLINES, and add one
# entry here. An outline enters only once the user has judged it by eye on
# real roads (ADR-0036).
SHAPES: dict[str, ShapeFn] = {
    "circle": circle,
    "heart": heart,
    "star": read_outline(OUTLINES / "star.json"),
    "horse": read_outline(OUTLINES / "horse.json"),
    "moon": read_outline(OUTLINES / "moon.json"),
    "cat": read_outline(OUTLINES / "cat.json"),  # with strokes: its eyes
    "fish": read_outline(OUTLINES / "fish.json"),  # with a stroke: its eye
    # The animals the user approved (TASK-065), all with strokes.
    "butterfly": read_outline(OUTLINES / "butterfly.json"),  # its antennae
    "snail": read_outline(OUTLINES / "snail.json"),  # its spiral and horns
    "dog_head": read_outline(OUTLINES / "dog_head.json"),  # eyes, nose, mouth
    "rabbit_head": read_outline(OUTLINES / "rabbit_head.json"),  # eyes, nose, mouth
    # The seasonal shapes the user approved (TASK-088), with strokes too.
    "pumpkin": read_outline(OUTLINES / "pumpkin.json"),  # carved eyes and grin
    "christmas_tree": read_outline(OUTLINES / "christmas_tree.json"),  # its star
    # The simple shapes the user approved (TASK-223), with pieces apart: the
    # app draws the first three with the pen up, the sun with the pen down.
    "smiley": read_outline(OUTLINES / "smiley.json"),  # eyes and smile
    "ghost": read_outline(OUTLINES / "ghost.json"),  # its eyes
    "donut": read_outline(OUTLINES / "donut.json"),  # its hole
    "sun": read_outline(OUTLINES / "sun.json"),  # eight rays
}

SUPPORTED_SHAPES: tuple[str, ...] = tuple(SHAPES)

# Shapes that look the same at any angle: the search may turn them freely.
# Every other shape stays upright, give or take a few degrees (ADR-0038).
FREE_ROTATION: frozenset[str] = frozenset({"circle"})


def get_shape(name: str) -> ShapeFn:
    try:
        return SHAPES[name]
    except KeyError:
        raise ValueError(
            f"unknown shape {name!r}; choose one of: {', '.join(SHAPES)}"
        ) from None


def in_pieces(name: str) -> bool:
    """Whether the shape called `name` can be drawn with the pen up
    (TASK-223): an outline with pieces, or with strokes lifted off."""
    shape = get_shape(name)
    return isinstance(shape, Outline) and shape.in_pieces
