"""Arc-length resampling of closed parametric curves."""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence

Point = tuple[float, float]

# Dense samples taken along the parameter before resampling by arc length.
DENSE_SAMPLES = 4096


def sample_closed(
    curve: Callable[[float], Point], samples: int = DENSE_SAMPLES
) -> list[Point]:
    """Sample `curve` at uniform t in [0, 2π]; the last point equals the first."""
    points = [curve(2.0 * math.pi * i / samples) for i in range(samples)]
    points.append(points[0])
    return points


def normalize(points: Sequence[Point]) -> list[Point]:
    """Center the bounding box on the origin and scale uniformly into [-1, 1]²."""
    xs = [x for x, _ in points]
    ys = [y for _, y in points]
    cx = (min(xs) + max(xs)) / 2.0
    cy = (min(ys) + max(ys)) / 2.0
    half = max(max(xs) - min(xs), max(ys) - min(ys)) / 2.0
    return [((x - cx) / half, (y - cy) / half) for x, y in points]


def resample_by_arc_length(polyline: Sequence[Point], n_points: int) -> list[Point]:
    """Return `n_points` vertices equally spaced along a closed polyline.

    The first vertex is the polyline's first point, and it is repeated at the
    end to close the curve, so the result has `n_points + 1` elements.
    """
    if n_points < 3:
        raise ValueError(f"a closed shape needs at least 3 points, got {n_points}")

    cumulative = [0.0]
    for a, b in zip(polyline, polyline[1:], strict=False):
        cumulative.append(cumulative[-1] + math.dist(a, b))
    total = cumulative[-1]

    vertices: list[Point] = []
    segment = 0
    for k in range(n_points):
        target = total * k / n_points
        while cumulative[segment + 1] < target:
            segment += 1
        length = cumulative[segment + 1] - cumulative[segment]
        f = (target - cumulative[segment]) / length if length else 0.0
        (x0, y0), (x1, y1) = polyline[segment], polyline[segment + 1]
        vertices.append((x0 + f * (x1 - x0), y0 + f * (y1 - y0)))
    vertices.append(vertices[0])
    return vertices


def resample_keeping_vertices(polyline: Sequence[Point], n_points: int) -> list[Point]:
    """Like `resample_by_arc_length`, but every vertex of the closed polyline
    stays: the points left up to `n_points` are spread over its sides by
    length, each side cut into equal parts. With more vertices than
    `n_points`, the vertices alone (TASK-037).
    """
    sides = list(zip(polyline, polyline[1:], strict=False))
    lengths = [math.dist(a, b) for a, b in sides]
    total = sum(lengths)
    extra = max(0, n_points - len(sides))
    shares = [extra * length / total for length in lengths]
    counts = [math.floor(share) for share in shares]
    # Largest remainders first; on a tie, the earlier side.
    order = sorted(range(len(sides)), key=lambda i: (counts[i] - shares[i], i))
    for i in order[: extra - sum(counts)]:
        counts[i] += 1
    vertices: list[Point] = []
    for ((x0, y0), (x1, y1)), count in zip(sides, counts, strict=True):
        for k in range(count + 1):
            f = k / (count + 1)
            vertices.append((x0 + f * (x1 - x0), y0 + f * (y1 - y0)))
    vertices.append(vertices[0])
    return vertices
