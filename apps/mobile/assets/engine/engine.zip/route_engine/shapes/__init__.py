"""Shape generators on the normalized square [-1, 1]².

A shape maps `n_points` to `n_points` vertices equally spaced by arc length,
plus the first vertex repeated at the end to close the curve. Nothing here
knows about latitude, longitude or metres.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from route_engine.shapes.circle import circle
from route_engine.shapes.heart import heart
from route_engine.shapes.outline import Outline, read_outline
from route_engine.shapes.resample import Point

ShapeFn = Callable[[int], list[Point]]

# Outlines drawn in JSON (ADR-0035), shipped with the package: the catalogue
# shapes and the ones only tried from the CLI, like the house.
OUTLINES = Path(__file__).with_name("outlines")

# Adding a shape: write its module, or its outline in OUTLINES, and add one
# entry here. An outline enters only once the user has judged it by eye on
# real roads (ADR-0036).
SHAPES: dict[str, ShapeFn] = {
    "circle": circle,
    "heart": heart,
    "star": read_outline(OUTLINES / "star.json"),
    "horse": read_outline(OUTLINES / "horse.json"),
    "moon": read_outline(OUTLINES / "moon.json"),
    "cat": read_outline(OUTLINES / "cat.json"),  # with strokes: its eyes
    "fish": read_outline(OUTLINES / "fish.json"),  # with a stroke: its eye
    # The animals the user approved (TASK-065), all with strokes.
    "butterfly": read_outline(OUTLINES / "butterfly.json"),  # its antennae
    "snail": read_outline(OUTLINES / "snail.json"),  # its spiral and horns
    "dog_head": read_outline(OUTLINES / "dog_head.json"),  # eyes, nose, mouth
    "rabbit_head": read_outline(OUTLINES / "rabbit_head.json"),  # eyes, nose, mouth
    # The seasonal shapes the user approved (TASK-088), with strokes too.
    "pumpkin": read_outline(OUTLINES / "pumpkin.json"),  # carved eyes and grin
    "christmas_tree": read_outline(OUTLINES / "christmas_tree.json"),  # its star
    # The simple shapes the user approved (TASK-223), with pieces apart: the
    # app draws the first three with the pen up, the sun with the pen down.
    "smiley": read_outline(OUTLINES / "smiley.json"),  # eyes and smile
    "ghost": read_outline(OUTLINES / "ghost.json"),  # its eyes
    "donut": read_outline(OUTLINES / "donut.json"),  # its hole
    "sun": read_outline(OUTLINES / "sun.json"),  # eight rays
    # The new shapes the user approved on real roads (TASK-418, TASK-419),
    # drawn by tools/draw_new_shapes.py (ADR-0346), with the pen down.
    "airplane": read_outline(OUTLINES / "airplane.json"),
    "anchor": read_outline(OUTLINES / "anchor.json"),  # its ring
    "bear_head": read_outline(OUTLINES / "bear_head.json"),  # eyes and snout
    "bicycle": read_outline(OUTLINES / "bicycle.json"),  # its wheels
    "cherries": read_outline(OUTLINES / "cherries.json"),
    "espresso_cup": read_outline(OUTLINES / "espresso_cup.json"),  # the steam
    "four_leaf_clover": read_outline(OUTLINES / "four_leaf_clover.json"),
    "leaning_tower": read_outline(OUTLINES / "leaning_tower.json"),
    "music_note": read_outline(OUTLINES / "music_note.json"),
    "pear": read_outline(OUTLINES / "pear.json"),
    "sailboat": read_outline(OUTLINES / "sailboat.json"),
    "swan": read_outline(OUTLINES / "swan.json"),
    "windmill": read_outline(OUTLINES / "windmill.json"),
    "wine_glass": read_outline(OUTLINES / "wine_glass.json"),
    # TASK-516 (ADR-0411): 25 more of TASK-418's outlines and ten shapes of
    # winter, the holidays and sport (tools/draw_theme_shapes.py), judged on
    # paper and on real roads; the app draws them with the pen down.
    "ball": read_outline(OUTLINES / "ball.json"),
    "bell": read_outline(OUTLINES / "bell.json"),
    "candy_cane": read_outline(OUTLINES / "candy_cane.json"),
    "colosseum": read_outline(OUTLINES / "colosseum.json"),
    "croissant": read_outline(OUTLINES / "croissant.json"),
    "dolphin": read_outline(OUTLINES / "dolphin.json"),
    "dome": read_outline(OUTLINES / "dome.json"),
    "easter_egg": read_outline(OUTLINES / "easter_egg.json"),
    "eiffel_tower": read_outline(OUTLINES / "eiffel_tower.json"),
    "flower": read_outline(OUTLINES / "flower.json"),
    "fox_head": read_outline(OUTLINES / "fox_head.json"),
    "gift": read_outline(OUTLINES / "gift.json"),
    "infinity": read_outline(OUTLINES / "infinity.json"),
    "leaf": read_outline(OUTLINES / "leaf.json"),
    "light_bulb": read_outline(OUTLINES / "light_bulb.json"),
    "medal": read_outline(OUTLINES / "medal.json"),
    "mountain": read_outline(OUTLINES / "mountain.json"),
    "owl": read_outline(OUTLINES / "owl.json"),
    "padlock": read_outline(OUTLINES / "padlock.json"),
    "peace": read_outline(OUTLINES / "peace.json"),
    "penguin": read_outline(OUTLINES / "penguin.json"),
    "pizza_slice": read_outline(OUTLINES / "pizza_slice.json"),
    "racket": read_outline(OUTLINES / "racket.json"),
    "reindeer": read_outline(OUTLINES / "reindeer.json"),
    "santa_hat": read_outline(OUTLINES / "santa_hat.json"),
    "scooter": read_outline(OUTLINES / "scooter.json"),
    "skis": read_outline(OUTLINES / "skis.json"),
    "snowflake": read_outline(OUTLINES / "snowflake.json"),
    "snowman": read_outline(OUTLINES / "snowman.json"),
    "stocking": read_outline(OUTLINES / "stocking.json"),
    "strawberry": read_outline(OUTLINES / "strawberry.json"),
    "triumphal_arch": read_outline(OUTLINES / "triumphal_arch.json"),
    "trophy": read_outline(OUTLINES / "trophy.json"),
    "turtle": read_outline(OUTLINES / "turtle.json"),
    "umbrella": read_outline(OUTLINES / "umbrella.json"),
}

SUPPORTED_SHAPES: tuple[str, ...] = tuple(SHAPES)

# Shapes that look the same at any angle: the search may turn them freely.
# Every other shape stays upright, give or take a few degrees (ADR-0038).
FREE_ROTATION: frozenset[str] = frozenset({"circle"})


def get_shape(name: str) -> ShapeFn:
    try:
        return SHAPES[name]
    except KeyError:
        raise ValueError(
            f"unknown shape {name!r}; choose one of: {', '.join(SHAPES)}"
        ) from None


def in_pieces(name: str) -> bool:
    """Whether the shape called `name` can be drawn with the pen up
    (TASK-223): an outline with pieces, or with strokes lifted off."""
    shape = get_shape(name)
    return isinstance(shape, Outline) and shape.in_pieces
